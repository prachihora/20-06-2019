function setBackground()
{
	let url=document.getElementById("backgroundvalue").value;
	console.log(url);
	let divbox=document.getElementById("box");
	divbox.style.backgroundImage="url('"+url+"')";
}