function setColor(){
	let inputValue=document.getElementById("colorvalue").value;
	let divBox=document.getElementById("box");
	let divBox1=document.getElementById("box1");
	divBox.style.background=inputValue;
	divBox.addEventListener("click",function(){
		divBox1.style.background=inputValue;
	})
		
	}

